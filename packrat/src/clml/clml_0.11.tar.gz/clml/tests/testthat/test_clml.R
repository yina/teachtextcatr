test_that("read libsvm file", {
  df <- read_libsvm_data("data/heart_scale.libsvm")
  ans <- as.factor(c(1,0,1,0,0))
  expect_equal(df$label[1:5], ans)
})