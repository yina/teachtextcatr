test_that("naive bayes classification", {
  cat(getwd())
  data <- read_libsvm_data("data/example_text.libsvm")
  
  clml.estimate.nfold("data/example_text.libsvm", classifier="naivebayes")
})