library(e1071)

# see http://stackoverflow.com/questions/7390173/svm-equations-from-e1071-r-package

# RFE R implementation
# http://archive.today/TuvYv
# https://github.com/johncolby/SVM-RFE/blob/master/msvmRFE.R
# http://www.uccor.edu.ar/paginas/seminarios/Software/SVM_RFE_R_implementation.pdf

# example
# http://support.brainvoyager.com/functional-analysis-statistics/89-multi-voxel-pattern-analysis/182-users-guide-support-vector-machines.html

data <- data.frame(y=c(1,1,1,0,0,0), x2=c(1.0,0.7,1.4,0.3,0.1,-0.2), x1=c(0.7,0.1,0.3,0.9,0.6,1.0))

fit <- svm(y ~ ., data=data, type='C-classification', kernel='linear', scale=FALSE)

w = t(fit$coefs) %*% fit$SV

t(w %*% t(as.matrix(data[,2:3]))) - fit$rho

# equal to 
fit$decision.values