# bbr

bbr_run <- function(trfile, tefile, .id=c(1)) {
  #cat("Using classifier bbr\n\n")
  modelfile <- paste("int/classifier", .id, ".model", sep="")
  trcall <- paste("software/bbrbmr3.0/BBRtrain3.0",
                  "--autosearch",
                  trfile,
                  modelfile)
  system(trcall, intern=TRUE)
  
  resultsfile <- paste("int/classifier", .id, ".results", sep="")
  tecall <- paste("software/bbrbmr3.0/BBRclassify3.0",
                  "-r",
                  resultsfile,
                  tefile,
                  modelfile)
  system(tecall, intern=TRUE)
  
  scores <- bbr_get_scores(resultsfile)
  labels <- bbr_get_labels(tefile)
  
  ans <- calc_auc(scores, labels)
  #plot_lift(scores, labels)
  
  return(ans)
}

bbr_get_scores <- function(resultsfile) {
  results <- read.table(resultsfile, sep=" ", header=FALSE)
  return(results$V1)
}

bbr_get_labels <- function(tefile) {
  testset <- read.table(tefile, header=FALSE, sep="\n")
  testset$V1 <- as.character(testset$V1)
  testset$V1 <- str_trim(testset$V1)
  testset$label <- as.factor(as.numeric(str_sub(testset$V1, 1, 1)))
  return(testset$label)
}

bbr_calc_auc <- function(tefile, resultsfile) {
  results <- read.table(resultsfile, sep=" ", header=FALSE)
  testset <- read.table(tefile, header=FALSE, sep="\n")
  testset$V1 <- as.character(testset$V1)
  testset$V1 <- str_trim(testset$V1)
  testset$label <- as.factor(as.numeric(str_sub(testset$V1, 1, 1)))
  
  ans <- calc_auc(results$V1, testset$label)
  return(ans)
}