fest_run <- function(trfile, tefile, .id=c(1)) {
  #cat("Using classifier fest for random forest\n\n")
  modelfile <- paste("int/classifier", .id, ".model", sep="")
  
  trcall <- paste("software/fest/festlearn",
                  "-c 3 -t 500",
                  trfile,
                  modelfile)
  show(trcall)
  system(trcall, intern=FALSE, wait=TRUE)
  
  resultsfile <- paste("int/classifier", .id, ".results", sep="")
  tecall <- paste("software/fest/festclassify",
                  tefile,
                  modelfile,
                  resultsfile)
  system(tecall, intern=FALSE, wait=TRUE)
  
  ans <- fest_calc_auc(tefile, resultsfile)
  
  return(ans)
}

fest_calc_auc <- function(tefile, resultsfile) {
  results <- read.table(resultsfile, sep=" ", header=FALSE)
  testset <- read.table(tefile, header=FALSE, sep="\n")
  testset$V1 <- as.character(testset$V1)
  testset$V1 <- str_trim(testset$V1)
  testset$label <- as.numeric(as.character(str_sub(testset$V1, 1, 1)))

  ans <- calc_auc(results$V1, testset$label)
  return(ans)
}