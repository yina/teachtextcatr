# evaluate command line classifiers

# settings...

# select classifier to use
# bbr
# libsvm
# mallet/ naive bayes
# random forest/ fest

# specify ram disk to write temporary files
# num folds in cross validation

# use write_for_holdout code.R code
# data is a libsvm string



#' calc_auc
#' @param score
#' @param label
#' @return score
#' @import pROC
calc_auc <- function(score, label) {
  auc <- auc(as.factor(label), score)
  return(auc[1])
}


plot_lift <- function(score, label) {
  pred <- prediction(score, as.factor(label))
  perf <- performance(pred, "lift", "rpp")
  plot(perf, colorize=T)
}

match_to_sensitivity <- function(label, score, sensmatch) {
  tmpdf <- data.frame(score=score, label=label)
  tmpdf <- tmpdf[order(tmpdf$score, decreasing=TRUE),]
  
  for (thr in 1:nrow(tmpdf)) {
    predicted <- c(rep.int(1, thr), rep.int(0, nrow(tmpdf)-thr))
    tmp <- confusionMatrix(predicted, tmpdf$label, positive="1")
    show(tmp)
    if (tmp$byClass[1] >= sensmatch) {
      show(tmp)
      break
    }
  }
}

# set.seed(100)
# 
# #filename <- "dist/tweet_stop_bi_P5.libsvm"
# #filename <- "dist/tweet_stop_stem_uni_P6.libsvm"
# #filename <- "dist/tweet_stop_stem_bi_P7.libsvm"
# #filenames <- c("dist/tweet_stop_uni_P4.libsvm")
# #filenames <- c("/Users/yina/Workspace/projects/research-nsqip/r_nsqip/nsqip10_ssi.libsvm")
# filenames <- c("/Users/yina/Workspace/projects/research-nsqip/r_nsqip/nsqip10_munged_ssi.libsvm")
# # filenames <- c("dist/tweet_stop_uni_P4.libsvm",
# #                "dist/tweet_stop_bi_P5.libsvm",
# #                "dist/tweet_stop_stem_uni_P6.libsvm",
# #                "dist/tweet_stop_stem_bi_P7.libsvm")
# 
# #classifiers <- c("nb", "fest", "bbr")
# #classifiers <- c("fest", "bbr")
# classifiers <- c("fest")
# 
# 
# 
# for (filename in filenames) {
#   cat("\nProcessing: ", filename)
#   data <- read_libsvm_data(filename)
#   
#   for (classifier in classifiers) {
#     cat("\n\tRunning: ", classifier)
#     results <- NULL
#     folds <- createFolds(data$label, k=4, list=TRUE)
#     
#     for (teidx in folds) {
#       cat(".")
#       write_split(data$body, teidx)
#       
#       # run classifier
#       eval(parse(text=paste(classifier, "_run()", sep="")))
#       auc <- eval(parse(text=paste(classifier, "_calc_auc()", sep="")))
#       
#       #   liblinear_run()
#       #   auc <- liblinear_calc_auc()
#       show(auc)
#       results <- rbind(results, auc)
#     }
#     show(results)
#     cat("\n\t\tmean: ", mean(results))
#     cat("\t\tsd: ", sd(results))
#   }
# }