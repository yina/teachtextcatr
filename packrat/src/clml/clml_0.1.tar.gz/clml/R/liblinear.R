# liblinear

liblinear_run <- function(trfile, tefile,.id=c(1)) {
  if (!file.exists("software/liblinear-1.96/train")) {
    cat("File executable train does not exist in liblinear-1.96. Please run make.")
  }
  #cat("Using classifier libsvm\n\n")
  modelfile <- paste("int/classifier", .id, ".model", sep="")
  trcall <- paste("software/liblinear-1.96/train",
                  "-q -s 7 -c 1",
                  #"-q -s 0 -t 0 -c 1 -b 1 -w0 0.984 -w1 0.016",
                  trfile,
                  modelfile)
  system(trcall, intern=TRUE)
  
  resultsfile <- paste("int/classifier", .id, ".results", sep="")
  tecall <- paste("software/liblinear-1.96/predict",
                  "-b 1",
                  tefile,
                  modelfile,
                  resultsfile)
  system(tecall, intern=TRUE)
  
  ans <- liblinear_calc_auc(tefile, resultsfile)
  #plot_lift(scores, labels)
  
  return(ans)
  
}

liblinear_calc_auc <- function(tefile, resultsfile) {
  results <- read.table(resultsfile, sep=" ", header=TRUE)
  testset <- read.table(tefile, header=FALSE, sep="\n")
  testset$V1 <- as.character(testset$V1)
  testset$V1 <- str_trim(testset$V1)
  testset$label <- as.factor(as.numeric(str_sub(testset$V1, 1, 1)))
  
  ans <- calc_auc(results$X1, testset$label)
  return(ans)
}


#liblinear_calc_auc <- function() {
#  return(libsvm_calc_auc())
#}