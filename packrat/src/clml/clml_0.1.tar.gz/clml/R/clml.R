#' extract_and_compile_cl
#' @export
prepare.clml <- function() {
  # check directories and create if they don't exist
  create.directories()
  unpack.tools()
}

create.directories <- function() {
  if (!file.exists("int")) {
    dir.create("int")
  }
  if (!file.exists("software")) {
    dir.create("software")
  }
  
}

unpack.tools <- function() {
  srcpath <- system.file(package="clml")
  untar(paste(srcpath, "/liblinear-1.96.tar.gz", sep=""), exdir="software")
  untar(paste(srcpath, "/mallet-2.0.7.tar.gz", sep=""), exdir="software")
  untar(paste(srcpath, "/bbrbmr3.0-mac.tar.gz", sep=""), exdir="software/bbrbmr3.0")
  untar(paste(srcpath, "/fest.tar.gz", sep=""), exdir="software")
  untar(paste(srcpath, "/libsvm-3.20.tar.gz", sep=""), exdir="software")
}

#' reads libsvm file
#'
#' @param libsvmfile A file location formatted in libsvm style
#' @return A data frame with two columns a row num, a label, and a body
#' @importFrom stringr str_trim
#' @importFrom stringr str_sub
#' @export
read_libsvm_data <- function(libsvmfile) {
  data = read.table(libsvmfile, sep="\n")
  data$V1 = as.character(data$V1)
  data$index <- 1:nrow(data)
  
  data$V1 <- str_trim(data$V1)
  data$label <- as.factor(as.numeric(str_sub(data$V1, 1, 1)))
  names(data)[1] <- "body"
  return(data)
}


#' clml.estimate.nfold
#' 
#' @param libsvmfile A file location formatted in libsvm style
#' @param classifiers A chracter vector of classifiers name as per convention
#' @param numfolds Number of folds to classify
#' @return vector of area under the curves for each fold
#' @export
#' @importFrom caret createFolds
#' @import plyr
clml.estimate.nfold <- function(libsvmfile, classifier="bbr", numfolds=5) {
  data <- read_libsvm_data(libsvmfile)
  
  # can write all the files to the ram disk first and then 
  folds <- createFolds(data$label, k=numfolds, list=TRUE)
  ltrtefiles <- ldply(folds, write_split, data=data$body)  
  results <- mdply(ltrtefiles, build_and_test_model, classifier, .parallel=FALSE)
  
  return(results$auc)
}

#' clml.estimate.holdout
#' 
#' @param libsvmfile A file location formatted in libsvm style
#' @param classifiers A chracter vector of classifiers name as per convention
#' @param numfolds Number of folds to classify
#' @return vector of area under the curves for each fold
#' @export
#' @importFrom caret createDataPartition
#' @import plyr
clml.estimate.holdout <- function(libsvmfile, classifier="bbr", holdout=0.8) {
  data <- read_libsvm_data(libsvmfile)
  splits <- createDataPartition(data$label, p=holdout)
  
  ltrtefiles <- ldply(splits, write_split, data=data$body)
  results <- mdply(ltrtefiles, build_and_test_model, classifier, .parallel=FALSE)
  
  # clean ltrtefiles
  clean_temp_space(rbind(ltrtefiles$trfile, ltrtefiles$tefile))
  
  return(results$auc)
}

#' build_and_test_model
#' 
#' @param trfile libsvm formatted training file
#' @param tefile libsvm formatted testing file
#' @param classifier libsvm, liblinear, nb, fest, bbr
#' @return data frame of auc
#' @export
build_and_test_model <- function(trfile, tefile, classifier,.id=c("1")) {
  runcommand = paste(classifier, "_run(\"", trfile, "\", \"", tefile, "\", \"", .id,"\")", sep="")
  auc <- eval(parse(text=runcommand))
  return(data.frame(auc=auc))
}

#' write_split
#' 
#' @param idx Indexes of test examples
#' @param data Data frame that contains data
#' @return vector of train and test filenames
write_split <- function(idx, data) {
  trdata = data[-idx]
  tedata = data[idx]
  
  trfilename <- paste("int/tmp_train", idx[1], ".dat", sep="")
  tefilename <- paste("int/tmp_test", idx[1], ".dat", sep="")
  
  write.table(trdata, file=trfilename, 
              row.names=FALSE, quote=FALSE, col.names=FALSE)
  write.table(tedata, file=tefilename, 
              row.names=FALSE, quote=FALSE, col.names=FALSE)
  return(c(trfile=trfilename, tefile=tefilename))
}

#' clean_temp_space
#' 
#' @param vector of characters of absolute file paths
clean_temp_space <- function(files) {
  lapply(list(files), function(x) unlink(x))
}

#' write_libsvm
#' 
#' @param data
#' @param filename
#' @param class
#' @export
write_libsvm <- function(data, filename= "out.dat", class = 1) {  
  out = file(filename) 
  writeLines(apply(data, 
                   1, 
                   function(X) {
                     #show(class(X))
                     #show(X)
                     #idx <- which(X!=0)[-class]
                     #val <- X[which(X!=0)[-class]]
                     idx <- which(X!=0)
                     val <- X[which(X!=0)]
                     int <- as.data.frame(cbind(idx, val ))
                     # remove row where idx == 1
                     int <- int[int$idx != 1,]
                     int$idx <- int$idx - 1
                     #show(int)
                     str <- paste(apply(int, 1, paste, collapse=":"), collapse=" ")
                     #show(str)
                     paste(X[class], str, collapse=" ") }), out) 
  close(out)
}