naivebayes_run <- function(trfile, tefile,.id=c(1)) {
  #cat("Using classifier naive bayes\n\n")
  malletfile <- paste("int/mallet", .id, ".dat", sep="")
  convert_to_malletcall <- paste("software/mallet-2.0.7/bin/mallet",
                                 "import-svmlight",
                                 "--input", trfile,
                                 "--output", malletfile)
  system(convert_to_malletcall, intern=TRUE)
  
  modelfile <- paste("int/classifier", .id, ".model", sep="")
  trcall <- paste("software/mallet-2.0.7/bin/mallet",
                  "train-classifier",
                  "--input", malletfile,
                  "--output-classifier", modelfile,
                  "--trainer NaiveBayes")
  system(trcall, intern=TRUE)
  
  resultsfile <- paste("int/classifier", .id, ".results", sep="")
  tecall <- paste("software/mallet-2.0.7/bin/mallet",
                  "classify-svmlight",
                  "--input", tefile,
                  "--classifier", modelfile,
                  "--output", resultsfile)
  system(tecall, intern=TRUE)
  
  ans <- naivebayes_calc_auc(tefile, resultsfile)
  return(ans)
}

naivebayes_calc_auc <- function(tefile, resultsfile) {
  results <- read.table(resultsfile, sep="\t", header=FALSE)
  testset <- read.table(tefile, header=FALSE, sep="\n")
  testset$V1 <- as.character(testset$V1)
  testset$V1 <- str_trim(testset$V1)
  testset$label <- as.factor(as.numeric(str_sub(testset$V1, 1, 1)))
  
  ans <- calc_auc(as.numeric(results$V3), testset$label)
  return(ans)
}