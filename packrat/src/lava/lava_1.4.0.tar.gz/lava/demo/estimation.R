example(estimate)
example(constrain)
example(curereg)
