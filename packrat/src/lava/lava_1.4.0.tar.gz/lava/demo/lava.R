demo(lava:::model)
demo(lava:::simulation)
demo(lava:::estimation)
demo(lava:::inference)

